# Display a popup

A Pen created on CodePen.io. Original URL: [https://codepen.io/bpo12/pen/rNqEdaa](https://codepen.io/bpo12/pen/rNqEdaa).

Add a popup to the map.

See the example: [https://docs.mapbox.com//mapbox-gl-js/example/popup/](https://docs.mapbox.com//mapbox-gl-js/example/popup/)